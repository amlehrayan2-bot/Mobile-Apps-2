import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Button, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
const Card =(props)=>{
  //const[count1,setCount1]=useState(10);
  return <Pressable onPress={()=> {props.set1(props.content1+1);props.set2( props.content2-1);}}>
         <View style={styles.card}>
             <Text style={{justifyContent: 'center',fontWeight:'bold'}}>{props.content1}</Text>
             <Text style={{justifyContent: 'center',fontWeight:'bold'}}>{props.content2}</Text>

          </View>





  </Pressable>






}





export default function App() {
  const[count1,setCount1]=useState(0);
  const[count2,setCount2]=useState(10);



  let card1=[
    {

      content1:count1,
      content2:count2,
      set1:setCount1,
      set2:setCount2,


    


    },
    {
      content1:count1,
      content2:count2,
      set1:setCount1,
      set2:setCount2,

    },
    {
      content1:count1,
      content2:count2,
      set1:setCount1,
      set2:setCount2,

    },
    {
      content1:count1,
      content2:count2,
      set1:setCount1,
      set2:setCount2,

    },
    {
      content1:count1,
      content2:count2,
      set1:setCount1,
      set2:setCount2,

    },

   






  ];






  const[count,setCount]=useState(0);




  return <View style={styles.container}>
    <ScrollView>
    <View><Text style={{color:'white' , fontSize:30, fontWeight:"400", marginBottom:30}}>pressable object</Text></View>

    <View style={{alignItems:'center'}}>
      <View style={{color:'black' , fontSize:30, fontWeight:"400", marginBottom:30,backgroundColor:"white", padding:20}}>{count}</View>
      <View style={{marginTop: 10 }} ><Button title=' when press me increment'  color="pink" onPress={()=>setCount(count+1)}/></View>
      <View style={{marginTop: 10 }} ><Button   title=' when press me decrement'  color="pink"  onPress={()=>setCount(count-1)}/></View>
      <View style={{marginTop: 10 }} ><Button title=' when press me  set 0'  color="pink"  onPress={()=>setCount(0)}/></View>
      <View style={{marginTop: 10 }} ><Button title=' when press me  set 10'  color="pink"  onPress={()=>setCount(10)}/></View>
    </View>
     {card1.map((obj)=><Card  content1={obj.content1} content2={obj.content2}  set1={obj.set1} set2={obj.set2}/>) } 
    

    
    </ScrollView>
  </View>
  ;
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: 'navy',
    alignItems: 'center',
    justifyContent:'flex-start',

    
  },
  card:{
    backgroundColor: 'beige',
    color:'navy',
    padding:40,
    borderRadius:30,
    width:'90%',
    alignItems:'center',
    //justifyContent:'center',
    marginTop:30,
  
  


    


  }
});
